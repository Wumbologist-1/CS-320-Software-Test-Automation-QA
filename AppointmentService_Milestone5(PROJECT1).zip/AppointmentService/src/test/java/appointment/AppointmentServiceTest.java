package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * AppointmentServiceTest.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Appointment Service
 *
 * Description:
 * This test class verifies the functionality of the AppointmentService
 * class. It ensures that appointments can be added and deleted while
 * enforcing service-level business rules.
 *
 * Test Coverage Includes:
 * - Successful appointment addition
 * - Prevention of duplicate appointment IDs
 * - Successful appointment deletion
 * - Exception handling for missing appointments
 *
 * These tests confirm proper service behavior and exception handling.
 */

public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    void setup() {
        service = new AppointmentService();
    }

    @Test
    void testAddAppointment_success() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a1 = new Appointment("A1", future, "Checkup");
        service.addAppointment(a1);
        assertNotNull(service.getAppointment("A1"));
    }

    @Test
    void testAddAppointment_duplicateId_throws() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a1 = new Appointment("A1", future, "Checkup");
        Appointment a2 = new Appointment("A1", future, "Other");
        service.addAppointment(a1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(a2));
    }

    @Test
    void testDeleteAppointment_success() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a1 = new Appointment("A1", future, "Checkup");
        service.addAppointment(a1);
        service.deleteAppointment("A1");
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("A1"));
    }

    @Test
    void testDeleteAppointment_missing_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("MISSING"));
    }
}
