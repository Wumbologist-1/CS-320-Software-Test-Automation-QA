package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

/**
 * AppointmentTest.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Appointment Service
 *
 * Description:
 * This test class validates the Appointment object’s field constraints
 * and business rules using JUnit 5.
 *
 * Test Coverage Includes:
 * - Valid appointment creation
 * - Null ID validation
 * - Maximum ID length enforcement
 * - Null date validation
 * - Past date rejection
 * - Null description validation
 * - Maximum description length enforcement
 *
 * These tests ensure that invalid input is rejected and that
 * all object constraints are strictly enforced.
 */

public class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        Appointment a = new Appointment("A1", future, "Dentist appointment");
        assertEquals("A1", a.getAppointmentId());
        assertNotNull(a.getAppointmentDate());
        assertEquals("Dentist appointment", a.getDescription());
    }

    @Test
    void testAppointmentIdNull_throws() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, future, "Desc")
        );
    }

    @Test
    void testAppointmentIdTooLong_throws() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", future, "Desc")
        );
    }

    @Test
    void testDateNull_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", null, "Desc")
        );
    }

    @Test
    void testDateInPast_throws() {
        Date past = new Date(System.currentTimeMillis() - 60_000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", past, "Desc")
        );
    }

    @Test
    void testDescriptionNull_throws() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", future, null)
        );
    }

    @Test
    void testDescriptionTooLong_throws() {
        Date future = new Date(System.currentTimeMillis() + 60_000);
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("A1", future, longDesc)
        );
    }
}
