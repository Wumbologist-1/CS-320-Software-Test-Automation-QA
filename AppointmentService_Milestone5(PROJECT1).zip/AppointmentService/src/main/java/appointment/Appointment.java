package appointment;

import java.util.Date;

/**
 * Appointment.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Appointment Service
 *
 * Description:
 * The Appointment class represents a scheduled appointment entity.
 * Each appointment contains a unique, non-updatable ID, a required
 * future appointment date, and a description.
 *
 * Constraints:
 * - appointmentId: Required, non-null, maximum 10 characters, not updatable.
 * - appointmentDate: Required, non-null, must not be in the past.
 * - description: Required, non-null, maximum 50 characters.
 *
 * Validation is enforced during object construction to ensure
 * data integrity and business rule compliance.
 */

public class Appointment {
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.trim().isEmpty() || appointmentId.length() > 10) {
            throw new IllegalArgumentException("appointmentId must not be null and must be <= 10 characters");
        }
        if (appointmentDate == null) {
            throw new IllegalArgumentException("appointmentDate must not be null");
        }
        // must not be in the past
        Date now = new Date();
        if (appointmentDate.before(now)) {
            throw new IllegalArgumentException("appointmentDate must not be in the past");
        }
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("description must not be null and must be <= 50 characters");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime()); // defensive copy
        this.description = description;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime()); // defensive copy
    }

    public String getDescription() {
        return description;
    }

    // ID is NOT updatable
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("appointmentDate must not be null");
        }
        Date now = new Date();
        if (appointmentDate.before(now)) {
            throw new IllegalArgumentException("appointmentDate must not be in the past");
        }
        this.appointmentDate = new Date(appointmentDate.getTime());
    }

    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("description must not be null and must be <= 50 characters");
        }
        this.description = description;
    }
}
