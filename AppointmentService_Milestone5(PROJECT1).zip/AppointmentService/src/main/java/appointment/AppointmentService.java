package appointment;

import java.util.HashMap;
import java.util.Map;

/**
 * AppointmentService.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Appointment Service
 *
 * Description:
 * The AppointmentService class manages Appointment objects using
 * an in-memory data structure. It supports adding and deleting
 * appointments while enforcing unique appointment IDs.
 *
 * Business Rules:
 * - No duplicate appointment IDs allowed.
 * - Appointments must exist before deletion.
 * - Operations on non-existent appointments throw exceptions.
 *
 * This service layer ensures consistent appointment management
 * and proper enforcement of business constraints.
 */

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("appointment must not be null");
        }
        String id = appointment.getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("appointmentId already exists");
        }
        appointments.put(id, appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("appointmentId must not be null");
        }
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("appointmentId does not exist");
        }
        appointments.remove(appointmentId);
    }

    // helper for tests (not required by rubric, but useful)
    public Appointment getAppointment(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("appointmentId must not be null");
        }
        Appointment a = appointments.get(appointmentId);
        if (a == null) {
            throw new IllegalArgumentException("appointmentId does not exist");
        }
        return a;
    }
}
