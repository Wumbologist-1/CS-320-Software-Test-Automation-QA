package task;

import java.util.Objects;

/**
 * Task.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Task Service
 *
 * Description:
 * The Task class represents a single task entity. Each task
 * contains a unique, non-updatable task ID, along with a name
 * and description that may be modified.
 *
 * Constraints:
 * - taskId: Required, non-null, maximum 10 characters, not updatable.
 * - name: Required, non-null, maximum 20 characters.
 * - description: Required, non-null, maximum 50 characters.
 *
 * Validation is enforced at object construction and through
 * setter methods to ensure data integrity.
 */

public class Task {
    private final String taskId;   // not updatable
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        validateTaskId(taskId);
        validateName(name);
        validateDescription(description);

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    private static void validateTaskId(String taskId) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid taskId");
        }
    }

    private static void validateName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }
    }

    private static void validateDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Task)) return false;
        Task task = (Task) o;
        return Objects.equals(taskId, task.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }
}
