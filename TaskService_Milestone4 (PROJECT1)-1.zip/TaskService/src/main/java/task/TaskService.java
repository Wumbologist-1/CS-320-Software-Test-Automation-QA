package task;

import java.util.HashMap;
import java.util.Map;

/**
 * TaskService.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Task Service
 *
 * Description:
 * The TaskService class manages Task objects using an in-memory
 * data structure. It supports adding, retrieving, updating,
 * and deleting tasks while enforcing unique task IDs.
 *
 * Business Rules:
 * - No duplicate task IDs allowed.
 * - Only name and description fields may be updated.
 * - Operations on non-existent tasks result in exceptions.
 *
 * This service layer ensures proper validation and consistent
 * task management behavior.
 */

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("task cannot be null");
        }
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task does not exist");
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        getTask(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getTask(taskId).setDescription(description);
    }

    public Task getTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        Task t = tasks.get(taskId);
        if (t == null) {
            throw new IllegalArgumentException("Task does not exist");
        }
        return t;
    }
}
