package task;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

/**
 * TaskTest.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Task Service
 *
 * Description:
 * This test class verifies the functionality and validation
 * logic of the Task class using JUnit 5.
 *
 * Test Coverage Includes:
 * - Valid task creation
 * - Null value validation
 * - Maximum length constraints
 * - Setter method validation
 *
 * The goal of these tests is to ensure all Task constraints
 * are enforced and invalid input results in appropriate exceptions.
 */

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task t = new Task("T1", "Write tests", "Create unit tests for the Task service");
        assertEquals("T1", t.getTaskId());
        assertEquals("Write tests", t.getName());
        assertEquals("Create unit tests for the Task service", t.getDescription());
    }

    @Test
    void testTaskIdNull_throws() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Name", "Desc"));
    }

    @Test
    void testTaskIdTooLong_throws() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("12345678901", "Name", "Desc"));
    }

    @Test
    void testNameNull_throws() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", null, "Desc"));
    }

    @Test
    void testNameTooLong_throws() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "123456789012345678901", "Desc")); // 21 chars
    }

    @Test
    void testDescriptionNull_throws() {
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "Name", null));
    }

    @Test
    void testDescriptionTooLong_throws() {
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 chars
        assertThrows(IllegalArgumentException.class, () ->
                new Task("T1", "Name", longDesc));
    }

    @Test
    void testSettersValidateFields() {
        Task t = new Task("T1", "Name", "Desc");
        assertThrows(IllegalArgumentException.class, () -> t.setName("123456789012345678901"));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription("123456789012345678901234567890123456789012345678901"));
    }
}
