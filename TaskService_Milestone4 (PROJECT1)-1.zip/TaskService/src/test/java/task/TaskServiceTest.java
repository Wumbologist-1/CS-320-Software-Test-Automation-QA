package task;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * TaskServiceTest.java
 *
 * Author: Luis Tomassini
 * Course: CS 320 – Software Testing
 * Assignment: Task Service
 *
 * Description:
 * This test class validates the behavior of the TaskService class.
 * It ensures that tasks can be added, retrieved, updated, and deleted
 * according to business rules.
 *
 * Test Coverage Includes:
 * - Adding tasks successfully
 * - Preventing duplicate task IDs
 * - Deleting existing tasks
 * - Handling missing task operations
 * - Updating task name and description
 *
 * These tests confirm proper enforcement of service-level rules
 * and exception handling.
 */

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void testAddTask_success() {
        Task t = new Task("T1", "Name", "Description");
        service.addTask(t);
        assertNotNull(service.getTask("T1"));
    }

    @Test
    void testAddTask_duplicateId_throws() {
        service.addTask(new Task("T1", "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () ->
                service.addTask(new Task("T1", "Other", "Other description")));
    }

    @Test
    void testDeleteTask_success() {
        service.addTask(new Task("T1", "Name", "Description"));
        service.deleteTask("T1");
        assertThrows(IllegalArgumentException.class, () -> service.getTask("T1"));
    }

    @Test
    void testDeleteTask_missing_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("MISSING"));
    }

    @Test
    void testUpdateName_success() {
        service.addTask(new Task("T1", "Old", "Description"));
        service.updateName("T1", "New");
        assertEquals("New", service.getTask("T1").getName());
    }

    @Test
    void testUpdateDescription_success() {
        service.addTask(new Task("T1", "Name", "Old"));
        service.updateDescription("T1", "New description");
        assertEquals("New description", service.getTask("T1").getDescription());
    }

    @Test
    void testUpdateMissingTask_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.updateName("MISSING", "New"));
    }

    @Test
    void testUpdateInvalidValue_throws() {
        service.addTask(new Task("T1", "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () ->
                service.updateDescription("T1", "123456789012345678901234567890123456789012345678901"));
    }
}
